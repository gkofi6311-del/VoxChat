package com.francis.voxchat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;

public class ChatInjector {

    public static void insert(String text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;

        client.execute(() -> {
            client.setScreen(new ChatScreen(text));
        });
    }
}