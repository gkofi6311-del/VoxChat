package com.francis.voxchat;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeybindHandler {

    public static KeyBinding toggle;

    public static void register() {
        toggle = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.voxchat.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.voxchat"
            )
        );
    }

    public static void tick() {
        while (toggle.wasPressed()) {
            SpeechManager.toggle();
        }
    }
}