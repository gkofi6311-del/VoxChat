package com.francis.voxchat;

import org.vosk.Model;
import org.vosk.Recognizer;

import javax.sound.sampled.*;
import java.io.IOException;

public class SpeechManager {

    private static boolean recording = false;
    private static Thread thread;

    public static void toggle() {
        if (!recording) start();
        else stop();
    }

    public static void start() {
        recording = true;
        System.out.println("Listening...");

        thread = new Thread(() -> {
            try {
                Model model = new Model("models/en"); // replace later
                Recognizer recognizer = new Recognizer(model, 16000.0f);

                AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
                DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);

                TargetDataLine mic = (TargetDataLine) AudioSystem.getLine(info);
                mic.open(format);
                mic.start();

                byte[] buffer = new byte[4096];

                while (recording) {
                    int bytesRead = mic.read(buffer, 0, buffer.length);
                    if (recognizer.acceptWaveForm(buffer, bytesRead)) {
                        String result = recognizer.getResult();
                        if (result.contains("text")) {
                            String text = result.split(""text" : "")[1].split(""")[0];
                            ChatInjector.insert(text);
                        }
                    }
                }

                mic.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        thread.start();
    }

    public static void stop() {
        recording = false;
        System.out.println("Stopped listening");
    }
}