package com.francis.voicetext;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;

public class ChatInjector {

    public static void insertIntoChat(String text) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client == null) return;

        client.execute(() -> {
            client.setScreen(new ChatScreen(text));
        });
    }
}