package com.francis.voicetext;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeybindHandler {

    public static KeyBinding toggleDictation;

    public static void register() {
        toggleDictation = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.voicetext.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.voicetext"
            )
        );
    }

    public static void tick() {
        while (toggleDictation.wasPressed()) {
            SpeechManager.toggleRecording();
        }
    }
}