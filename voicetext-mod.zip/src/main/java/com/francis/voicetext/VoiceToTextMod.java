package com.francis.voicetext;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class VoiceToTextMod implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        KeybindHandler.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            KeybindHandler.tick();
        });

        System.out.println("VoiceText loaded!");
    }
}