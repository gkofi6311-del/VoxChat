package com.francis.voicetext;

public class SpeechManager {

    private static boolean recording = false;

    public static void toggleRecording() {
        if (!recording) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    public static void startRecording() {
        recording = true;
        System.out.println("Listening...");
    }

    public static void stopRecording() {
        recording = false;
        System.out.println("Stopped listening");

        String recognizedText = "Hello this is voice text";
        ChatInjector.insertIntoChat(recognizedText);
    }
}